require('dotenv').config();
var loadup=require("./services/loadup");
var express = require('express');
var app = express();
//var authentication = require('./services/simpleauthentication');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var csvWriter = require('csv-write-stream');
var fs = require('fs');
var logger = require('./lib/logging');
var mime = require('mime');
var Organization = require('./models/organization');
var orgloader = require('./middleware/orgloader');
var path = require('path');
var request = require('./services/request');
var t = require("./services/timelogged");
var time = require('./lib/time');
var _ = require('underscore');
var moment = require('moment');

app.set('view engine', 'pug');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(orgloader.run);
app.use(express.static('public'));

/**
 * A webhook that is executed when an organization installs this plugin on their instance.
 */
app.post('/installed', function(req, res) {
    var new_client = new Organization({
        client_key: req.body.clientKey,
        public_key: req.body.publicKey,
        shared_secret: req.body.sharedSecret,
        server_version: req.body.serverVersion,
        plugins_version: req.body.pluginsVersion,
        base_url: req.body.baseUrl
    });

    console.log("Your client key is: " + new_client.client_key);
    console.log("Your secret key is: " + new_client.shared_secret);
    console.log("Your base url is:", new_client.base_url);
    console.log("Your public key is:", new_client.public_key);

    new_client.insert().then(function(db_results) {
        res.status(204).send();
        logger.debug("%s installed MSOE Timer Logger!", new_client.base_url);

    }).catch(function(err) {
        logger.error(new_client.base_url + " " + err.message);
        console.log(err.message);
        res.status(500).send();
    });
});

app.post('/uninstalled', function(req, res) {
    res.status(204).send();
    var existing_client = new Organization({
        client_key: req.body.clientKey,
        public_key: req.body.publicKey,
        shared_secret: req.body.sharedSecret,
        server_version: req.body.serverVersion,
        plugins_version: req.body.pluginsVersion,
        base_url: req.body.baseUrl
    });

    console.log("Deleting entry where: ");
    console.log("    Client key is: " + existing_client.client_key);
    console.log("    Secret key is: " + existing_client.shared_secret);
    console.log("    Base url is: ", existing_client.base_url);
    console.log("    Public key is: ", existing_client.public_key);

    existing_client.remove().then(function(db_results) {
        res.status(204).send();
        logger.debug("%s uninstalled MSOE Timer Logger!", existing_client.base_url);

    }).catch(function(err) {
        console.log(err.message);
        logger.error("%s : Error Uninstalling : %s", existing_client.base_url, err.message);
        res.status(500).send();
    });
});

app.post('/enabled', function(req, res) {
    res.status(204).send();
});

app.post('/disabled', function(req, res) {
    res.status(204).send();
});

app.get('/main', function (req, res) {
    var recentNum = 0; // default number of

    loadup.loadPL(req, recentNum).then(function(results){

        res.render('index', {
            title: 'MSOE Time Log Viewer',
            project:results,
            host: encodeURIComponent(req.jwt.base_url), //"https://msoese.atlassian.net"
            alljs: req.jwt.base_url + "/atlassian-connect/all.js", //"https://msoese.atlassian.net"
            pn: req.cookies.pn,
            from: req.cookies.from,
            to: req.cookies.to
        });
    });
});

app.get('/', function (req, res) {
    res.send('Hello World!');
});

app.post('/allProjects',function (req, res) {
    loadup.loadPL(req, req.body.recent).then(function (results) {
        res.send({projects: results});
    });
});

/**
 * Team member total time logged for given date.
 *
 **/
app.post("/timeresultsForSprint", function (req, res) {
    var pn = req.body.projectList.split(',')[1];
    var sprint = req.body.sprintList;
    var sprint_array=loadup.getSprintArray();

    var startdate;
    var enddate;
    if(sprint_array !== undefined){
        for(var i=0;i<sprint_array.length;i++) {
            if (sprint_array[i].sprint.name === sprint) {
                startdate=sprint_array[i].sprint.startDate;
                enddate=sprint_array[i].sprint.endDate;
            }
        }
    }

    var start, end, formatted_start, formatted_end, filename;
    if (req.body.usingSprintForm === "true") {
        start = startdate.substring(0,10);
        end = enddate.substring(0,10);
        formatted_start = start.substring(5,7) + "/" + start.substring(8,10) + "/" + start.substring(0,4);
        formatted_end = end.substring(5,7) + "/" + end.substring(8,10) + "/" + end.substring(0,4);
        filename = __dirname + '/' + req.body.projectList.split(',')[1].toUpperCase() + '-' + start + '.csv';
    } else {
        formatted_start = req.body.from;
        start = formatted_start.substring(6,10) + "-" + formatted_start.substring(0,2) + "-" + formatted_start.substring(3,5);
        formatted_end = req.body.to;
        end = formatted_end.substring(6,10) + "-" + formatted_end.substring(0,2) + "-" + formatted_end.substring(3,5);
        filename = __dirname + '/' + pn.toUpperCase() + '-' + formatted_start + '.csv';
    }

    t.getTasks(req, pn, start, end).then(function (results) {
        res.cookie('pn' , req.body.projectList.split(',')[1], {expires: moment().add(1, 'months').toDate()});
        res.cookie('from' , req.body.from, {expires: moment().add(1, 'months').toDate()});
        res.cookie('to' , req.body.to, {expires: moment().add(1, 'months').toDate()});
        res.cookie('usingSprintForm', req.body.usingSprintForm, {expires: moment().add(1, 'months').toDate()});
        res.cookie('allProjectsChecked', req.body.showAllProjects, {expires: moment().add(1, 'months').toDate()});
        res.cookie('sprintList', req.body.sprintList, {expires: moment().add(1, 'months').toDate()});
        // console.log(results) if this if-statement fails. Something is undefined
        if (results && results.user_array && results.task_array && results.user_array[Object.keys(results.user_array)[0]]) {
            return res.render('custom', {
                title: 'MSOE Time Logger',
                alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                message: formatted_start + ' - ' + formatted_end,
                user: results.user_array,
                task: results.task_array,
                dateHeader: results.user_array[Object.keys(results.user_array)[0]],
                totalDays: results.totalDays,
                host: encodeURIComponent(req.jwt.base_url),
                file: filename
            });
        } else {
            res.render('index', {
                title: 'MSOE Time Logger',
                host: encodeURIComponent(req.jwt.base_url),
                alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                error: "An error has occured. Please try again later."
            });

            logger.debug("%s - %s", req.jwt.base_url, "No time log for specified date range.");
        }
    }).catch(function (err) {
        res.render('index', {
            title: 'MSOE Time Logger',
            host: encodeURIComponent(req.jwt.base_url),
            alljs: req.jwt.base_url + "/atlassian-connect/all.js",
            error: "An error has occured. Please try again later."
        });

        logger.error("%s - %s", req.jwt.base_url, err.message);
    });
});

app.get('/gadgetmain', function (req, res) {
    // If cookie doesn't exist, display main page
    loadup.loadPL(req).then(function(results1) {
        console.log(req.cookies.pn);
        if(typeof req.cookies.pn === 'undefined' ) {
            res.render('index-gadget', {
                title: 'MSOE Time Log Viewer',
                project: results1.project_array,
                host: encodeURIComponent(req.jwt.base_url),
                alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                pn: req.cookies.pn
            });
        } else {
            // If cookie exists, display saved project
            loadup.getSprintInfo(req, req.cookies.pn).then(function() {
                // Sprint data
                var sprint_array = loadup.getSprintArray();
                // Format date to display on top of page
                var startdate = sprint_array[sprint_array.length-1].sprint.startDate;
                var enddate = sprint_array[sprint_array.length-1].sprint.endDate;
                var start = startdate.substring(0,10);
                var end = enddate.substring(0,10);

                var pn = req.cookies.pn;
                var formatted_start = start.substring(5,7) + "/" + start.substring(8,10) + "/" + start.substring(0,4);
                var formatted_end = end.substring(5,7) + "/" + end.substring(8,10) + "/" + end.substring(0,4);
                // Populate table
                t.getTasks(req, pn, start, end).then(function (results) {
                    // console.log(results) if this if-statement fails. Something is undefined
                    if (results && results.user_array && results.task_array && results.user_array[Object.keys(results.user_array)[0]]) {
                        return res.render('gadget', {
                            title: 'MSOE Time Logger',
                            alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                            pnmessage:pn,
                            message: formatted_start + ' - ' + formatted_end,
                            user: results.user_array,
                            task: results.task_array,
                            sprintlist:sprint_array,
                            dateHeader: results.user_array[Object.keys(results.user_array)[0]],
                            totalDays: results.totalDays,
                            host: encodeURIComponent(req.jwt.base_url)
                        });
                    } else {
                        res.render('index-gadget', {
                            title: 'MSOE Time Logger',
                            host: encodeURIComponent(req.jwt.base_url),
                            alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                            error: "An error has occured. Please try again later."
                        });

                        logger.debug("%s - %s", req.jwt.base_url, "No time log for specified date range.");
                    }
                }).catch(function (err) {
                    res.render('index-gadget', {
                        title: 'MSOE Time Logger',
                        host: encodeURIComponent(req.jwt.base_url),
                        alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                        error: "An error has occured. Please try again later."
                    });

                    logger.error("%s - %s", req.jwt.base_url, err.message);
                });
            })
        }
    }).catch(function (err) {
        res.render('index', {
            title: 'MSOE Time Logger',
            host: encodeURIComponent(req.jwt.base_url),
            alljs: req.jwt.base_url + "/atlassian-connect/all.js",
            error: "An error has occured. Please try again later."
        });

        logger.error("%s - %s", req.jwt.base_url, err.message);
    })
});

app.post("/getInfoForOtherSprint",function (req,res) {
    var sprintname = req.body.sprintList;
    var pn = req.cookies.pn;
    var sprint_array = loadup.getSprintArray();
    var startdate; 
    var enddate;

    for (var count in sprint_array){
        if(sprint_array[count].sprint.name === sprintname){
            startdate = sprint_array[count].sprint.startDate;
            enddate = sprint_array[count].sprint.endDate;
        }
    }

    // Format date to display on top of page
    var start = startdate.substring(0, 10);
    var end = enddate.substring(0, 10);
    var formatted_start = start.substring(5, 7) + "/" + start.substring(8, 10) + "/" + start.substring(0, 4);
    var formatted_end = end.substring(5, 7) + "/" + end.substring(8, 10) + "/" + end.substring(0, 4);

    t.getTasks(req, pn, start, end).then(function (results) {
        //console.log(results) //if this if-statement fails. Something is undefined
        if (results && results.user_array && results.task_array && results.user_array[Object.keys(results.user_array)[0]]) {
            return res.render('gadget', {
                title: 'MSOE Time Logger',
                alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                pnmessage:pn,
                message: formatted_start + ' - ' + formatted_end,
                user: results.user_array,
                task: results.task_array,
                sprintlist:sprint_array,
                dateHeader: results.user_array[Object.keys(results.user_array)[0]],
                totalDays: results.totalDays,
                host: encodeURIComponent(req.jwt.base_url)
            });
        } else {
            res.render('index', {
                title: 'MSOE Time Logger',
                host: encodeURIComponent(req.jwt.base_url),
                alljs: req.jwt.base_url + "/atlassian-connect/all.js",
                error: "An error has occured. Please try again later."
            });

            logger.debug("%s - %s", req.jwt.base_url, "No time log for specified date range.");
        }
    }).catch(function (err) {
        res.render('index', {
            title: 'MSOE Time Logger',
            host: encodeURIComponent(req.jwt.base_url),
            alljs: req.jwt.base_url + "/atlassian-connect/all.js",
            error: "An error has occured. Please try again later."
        });

        logger.error("%s - %s", req.jwt.base_url, err.message);
    });
}); 

/**
 * Generates report, downloads it, and removes it from server.
 * Referenced in /timeresults Export CSV button
 **/
app.post('/download', function(req, res){
    var file = req.body.filename; // Report filepath
    var dataForCSV = []; // Array for writing data to csv
    var headerForCSV = ['User', 'Total'];
    var dateHeader = JSON.parse(req.body.dateHeader); // dateHeader from /timeresults
    var user = JSON.parse(req.body.user); // User array from /timeresults
    var totalDays = req.body.totalDays;
    // Iterate thru and add dates to the csv header
    _.each(dateHeader, function(date) {
        _.each(date, function(task) {
            if (task.date !== null)
                headerForCSV.push(task.date);
        })
    });
    // Buffer for task information just incase small date range
    for(i = 0; i < 5; i++) {headerForCSV.push('')}
    // Write user data (influenced by table in custom.pug)
    var writer = csvWriter({headers: headerForCSV});
    writer.pipe(fs.createWriteStream(file));
    _.each(user, function(user) {
        dataForCSV.push(user.name);
        dataForCSV.push(user.totalTime);
        _.each(user.dailyTime, function(dt) {
            if (dt.timeSpent > 0) {
                dataForCSV.push(dt.timeSpent)
            } else {
                dataForCSV.push('')
            }
        });
        writer.write(dataForCSV);
        dataForCSV = [];
    });
    // Daily hours total
    dataForCSV.push('Daily hours total:');
    dataForCSV.push('');
    _.each(dateHeader.dailyTime, function(d) {
        var dailyTotal = 0;
        _.each(user, function(user) {
            _.each(user.dailyTime, function(dt) {
                // Iterate thru all user daily time and sum daily total
                if (dt.date === d.date)
                    dailyTotal += dt.timeSpentSeconds
            })
        });
        // If no work completed on a given day, print '' | else print calculated total for all dataForCSV
        if (dailyTotal === 0) {
            dataForCSV.push('')
        } else {
            if (dailyTotal % 3600 === 0)
                dataForCSV.push((dailyTotal/3600).toFixed(0));
            else
                dataForCSV.push((dailyTotal/3600).toFixed(2));
        }
    });
    writer.write(dataForCSV);
    dataForCSV = [];
    // Weekly hours total
    dataForCSV.push('Weekly hours total:');
    dataForCSV.push('');
    var count = 1; // Used to print if range doesn't end on a Sunday
    // Iterate thru every date once (dateHeader)
    _.each(dateHeader.dailyTime, function(d) {
        var weeklyTotal = 0;
        // Iterate thru all user daily time and sum to weekly total if day is in week
        _.each(user, function(user) {
            _.each(user.dailyTime, function(dt) {
                if (dt.endOfWeek.week === d.endOfWeek.week)
                    weeklyTotal += dt.endOfWeek.weekTime
            })
        });
        // If day is a Sunday, print out weekly total | else if not Sunday, but last day in range print total
        if (d.endOfWeek.week === d.date || count === totalDays) {
            if (weeklyTotal/3600 > 0) {
                if (weeklyTotal % 3600 === 0)
                    dataForCSV.push((weeklyTotal/3600).toFixed(0));
                else
                    dataForCSV.push((weeklyTotal/3600).toFixed(2));
            } else {
                dataForCSV.push('');
            }
        } else {
            dataForCSV.push('')   ;
        }
        count++;
    });
    writer.write(dataForCSV);
    writer.write('\n\n');
    writer.write(['User', 'Date', 'Key', 'Time (h)', 'Description']);
    // Write worklog information (influenced by custom.js)
    _.each(user, function(user) {
        _.each(user.dailyTime, function(dt) {
            var url  = dt.url.split('^'); // URL for issues
            url.splice(-1); // Remove empty element from end
            var wlogid = dt.worklogs.id.split('^'); // The key for each worklog
            wlogid.splice(-1); // Remove empty element from end
            var wlogtime = dt.worklogs.time.split('^'); // The time for each worklog
            wlogtime.splice(-1); // Remove empty element from end
            var wlogdesc = dt.worklogs.desc.split('^'); // The comment for each worklog
            wlogdesc.splice(-1); // Remove empty element from end

            var dataArray = []; // Store each worklog data as an object
            for (var i = 0; i < url.length; i++) {
                // Format time in hours
                var t = wlogtime[i]/3600;
                if (wlogtime[i]%3600 === 0)
                    t = t.toFixed(0);
                else
                    t = t.toFixed(2);
                var data = {
                    id: wlogid[i],
                    time: t,
                    desc: wlogdesc[i],
                    date: dt.date
                };
                dataArray[i] = data;
            }
            _.each(dataArray, function(e){
                writer.write([user.name, e.date, e.id, e.time, e.desc]);
            });
        })
    });
    writer.end();

    // Make file auto-downloadable by setting attributes
    var filename = path.basename(file);
    var mimetype = mime.lookup(file);

    res.setHeader('Content-disposition', 'attachment; filename=' + filename);
    res.setHeader('Content-type', mimetype);

    // Download file and then delete from server to keep file structure neat
    var filestream = fs.createReadStream(file);
    filestream.pipe(res);
    fs.unlinkSync(file);
});


// This will allow us to host files statically like with `http-server`
app.use(express.static('public'));

app.listen(8081, function () {
    console.log('Example app listening on port 8081!');
});

app.post('/endpoint', function(req, res){
    loadup.getSprintInfo(req, req.body.project.split(',')[0]).then(function(results) {
        res.send({sprint: results});
    });
});

app.post('/gadgetendpoint', function(req, res) {
    loadup.getSprintInfo(req, req.body.project.split(',')[1]).then(function(results) {
        res.send({sprint: results});
    });
});
